# x7x-txt
#rm -rf kadiro
#https://github.com/Kadiro2005/x7x-txt/edit/main/README.md
#cd kadiro
#python bad_enc.py
